const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");

require("dotenv").config({ path: ".env" });

const { dbConnect } = require("./utils/dbConnect");

const app = express();

const PORT = process.env.PORT || 8080;

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(cors());




//@import Routers
const PettyCashVoucherRouter = require("./routes/pcv.route");
const PettyCashParticularRouter = require("./routes/pcp.route");
const UserRouter = require("./routes/user.route");

app.use("/api/pcv", PettyCashVoucherRouter);
app.use("/api/pcp", PettyCashParticularRouter);
app.use("/api/user", UserRouter);

//Execute Databse Connection
dbConnect();

app.listen(PORT, () => {
  console.log(`Server is up and running on port number: ${PORT}`);
});
