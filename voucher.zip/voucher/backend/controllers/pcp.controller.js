const PettycashParticular = require("../models/pcp.model");
const Pettycashvoucher = require("../models/pcv.model");



//create

const CreateParticular = async (req,res) => {
    try{
        const id = req.params.id;
         const Particular = await Pettycashvoucher.find({"voucherId":id});
        //const {particulars:[date,description,amount]} = req.body;
        const {description} = req.body;

         

        const createdParticular = await PettycashParticular.create({
            voucherID:id,
            particulars:{
                date:Particular[0].issuedDate,
                description:description,
                amount:Particular[0].totalAmount
        }
       });
        return res.status(200).send({ success: true, AddedParticular: createdParticular });
    } catch (e) {
      return res.status(500).send({ success: false, message: e.message });
    }
}

//getallparticulars

const GetAllParticulars = async (req, res) => {
    try{
        const Particulars = await PettycashParticular.find();
        return res.status(200).send({ success: true, Particulars: Particulars });
    } catch (e) {
      return res.status(500).send({ success: false, message: e.message });
    }
}



module.exports = {
    CreateParticular,
    GetAllParticulars
  };