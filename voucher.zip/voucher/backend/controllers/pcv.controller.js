const Pettycashvoucher = require("../models/pcv.model");

//create

const CreateVoucher = async (req, res) => {

try{
    const {
        requestor,
        department,
        totalAmount,
        preparedBy,
        preparedDate,
        authorizedBy,
        authorizedDate,
        issuedBy,
        issuedDate,
        VStatus,
      } = req.body;

  var records = [];
  records = await Pettycashvoucher.find();
  var x = records.length + 1;
  var vId = x*(x + 1) / 2;
  const voucherId = "PV-"+vId;

  console.log(voucherId)

  const createdVoucher = await Pettycashvoucher.create({
    voucherId:voucherId,
    requestor:requestor,
    department:department,
    totalAmount:totalAmount,
    preparedBy:preparedBy,
    preparedDate:preparedDate,
    authorizedBy:authorizedBy,
    authorizedDate:authorizedDate,
    issuedBy:issuedBy,
    issuedDate:issuedDate,
    VStatus:VStatus,
  });
  return res.status(200).send({ success: true, AddedVoucher: createdVoucher });
}catch(e){
    return res.status(500).send({ success: false, message: e.message });
}
};

//get all

const GetAllVouchers = async (req, res) => {
    try{
        const Vouchers = await Pettycashvoucher.find();
        return res.status(200).send({ success: true, Vouchers: Vouchers });
    } catch (e) {
      return res.status(500).send({ success: false, message: e.message });
    }
};

const DeleteVouchers = async (req, res) => {
  id = req.params.id;
  try {
    const Vouchers = await Pettycashvoucher.findById(id);
    if (!Vouchers) {
      throw new Error("There is no Voucher to delete");
    }
    const deleteVoucher = await Pettycashvoucher.findByIdAndDelete(id);
    res.status(200).send({ status: "voucher deleted", voucher : deleteVoucher });
  } catch (error) {
    res
      .status(500)
      .send({ status: "error with id", error: error.message });
  }
};





module.exports = {
  CreateVoucher,
  GetAllVouchers,
  DeleteVouchers
};
