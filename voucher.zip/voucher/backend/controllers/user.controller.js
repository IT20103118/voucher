const User = require("../models/user.model");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

//register

const RegisterUser = async (req,res) => {
try{
    const {fName, lName, gender, mobile, username, usertype, password, status } = req.body;

    const existingUser = await User.findOne({username: username});

    if(existingUser){
       throw new Error("User already exists");
    }
    
     const createdUser = {
       fName,
        lName, 
        gender, 
        mobile, 
        username, 
        usertype,
        password,
         status
     };
   
     const newuser = new User(createdUser);
     await newuser.save();
     const token = await newuser.generateAuthToken();
     res
       .status(201)
       .send({ status: "User Created", user: newuser, token: token });
       console.log(createdUser);
   } catch (error) {
     console.log(error.message);
     res.status(500).send({error: error.message});
   }
 };
    

//login
const LoginUser = async (req,res) => {
    try {
        const {username, password} = req.body
        const user = await User.findByCredentials(username, password)
        const token = await user.generateAuthToken()
        res.status(200).send({success:true, token: token, user: user})
    
      } catch (error) {
        res.status(500).send({ error: error.message });
        console.log(error);
      }
    };

//user logout
const LogOut = async (req,res)=>{
    try{
      req.User.tokens = req.User.tokens.filter((token)=>{
        return token.token !== req.token;
      });
      await req.User.save();
      res.status(200).save("Logout Successfully!!!!");
  
    }catch (error) {
      res.status(500).send({ error: error.message });
      console.log(error);
    }
  };

  //user profile
const GetProfile = async (req, res) => {
    try {
        console.log(req.User);
      res.status(201)
      res.send({ status: "User Details fetched", User: req.User});
    } catch (error) {
      res.status(500)
      res.send({ status: "Error with userprofile", error: error.message });
    }
  };

//staff member update profile
const ProfileUpdate =  async (req, res) => {
    try {
    const { 
        fName,
        lName, 
        gender, 
        mobile, 
        username, 
        usertype,
         status
          } = req.body
  
      let user = await User.findOne({username})
   
      if (!user) {
        throw new Error('There is no user account')
      }
      const userUpdate = await User.findByIdAndUpdate(req.user.id, 
        {
            fName:fName,
            lName:lName, 
            gender:gender, 
            mobile:mobile, 
            username:username, 
            usertype:usertype,
             status:status
      })
      res.status(200).send({status: 'User Profile Updated', User: userUpdate})
  
    } catch (error) {
      res.status(500).send({error: error.message})
      console.log(error)
    }
  };

  // delete user
const ProfileDelete = async (req, res) => {
    try {
      const user = await User.findById(req.user.id);
      if (!user) {
        throw new Error("There is no User to delete");
      }
      const deleteProfile = await User.findByIdAndDelete(req.user.id);
      res.status(200).send({ status: "user deleted", user : deleteProfile });
    } catch (error) {
      res
        .status(500)
        .send({ status: "error with id", error: error.message });
    }
  };



//get users
const GetUsers = async (req,res) => {
    try{
        const Users = await User.find({}, "-password");
        return res.status(200).send({ success: true, Users: Users });
    } catch (e) {
      return res.status(500).send({ success: false, message: e.message });
    } 
}


module.exports = {RegisterUser, LoginUser, GetUsers, LogOut, GetProfile, ProfileUpdate, ProfileDelete};