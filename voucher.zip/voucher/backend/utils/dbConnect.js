const mongoose = require("mongoose");

const dbConnect = () => {
  const dbConStr = process.env.MONGODB_URL;
  process.env.SUPPRESS_NO_CONFIG_WARNING = 'y';

  mongoose.connect(dbConStr, () => {
    console.log("Mongodb connection success!!");
  });
};

module.exports = { dbConnect };
