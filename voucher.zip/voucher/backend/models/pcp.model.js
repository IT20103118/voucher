const mongoose = require("mongoose");

const PettyCashParticularsSchema = new mongoose.Schema({
  voucherID: {
    type: String,
    required: false,
   },
  particulars: {
    
      date: {
        type: String,
        required: false,
      },
      description: {
        type: String,
        required: false,
      },
      amount: {
        type: String,
        required: false,
      },
    
},
});

const PettyCashParticulars = mongoose.model(
  "PettyCashParticulars",
  PettyCashParticularsSchema
);
module.exports = PettyCashParticulars;
