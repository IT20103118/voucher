const mongoose = require("mongoose");

const PettyCashVoucherSchema = new mongoose.Schema({
  voucherId: {
    type: String,
    required: true,
  },
  requestor: {
    type: String,
    required: true,
  },
  department: {
    type: String,
    required: true,
  },
  totalAmount: {
    type: Number,
    required: true,
  },
  preparedBy: {
    type: String,
    required: true,
  },
  preparedDate: {
    type: String,
    required: true,
  },
  authorizedBy: {
    type: String,
    required: true,
  },
  authorizedDate: {
    type: String,
    required: true,
  },
  issuedBy: {
    type: String,
    required: true,
  },
  issuedDate: {
    type: String,
    required: true,
  },
  VStatus: {
    type: Number,
    required: true,
  },
});

const PettyCashVoucher = mongoose.model(
  "PettyCashVoucher",
  PettyCashVoucherSchema
);
module.exports = PettyCashVoucher;
