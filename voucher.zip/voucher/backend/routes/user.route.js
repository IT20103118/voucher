const express = require("express");
const UserRouter = express.Router();
const userauth = require("../middleware/userauth");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

const {
  RegisterUser,
  LoginUser,
  GetUsers,
  LogOut,
  GetProfile,
  ProfileUpdate,
  ProfileDelete,
} = require("../controllers/user.controller");

UserRouter.post("/", RegisterUser);
UserRouter.post("/login", LoginUser);
UserRouter.get("/all", GetUsers);
UserRouter.get("/logout", userauth, LogOut);
UserRouter.get("/profile", userauth, GetProfile);
UserRouter.put("/update", userauth, ProfileUpdate);
UserRouter.delete("/delete", userauth, ProfileDelete);
module.exports = UserRouter;
