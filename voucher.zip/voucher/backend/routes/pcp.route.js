const express = require("express");
const PettyCashParticularRouter = express.Router();

const {CreateParticular, GetAllParticulars} = require("../controllers/pcp.controller");

PettyCashParticularRouter.post("/:id", CreateParticular);
PettyCashParticularRouter.get("/", GetAllParticulars);


module.exports = PettyCashParticularRouter;