const express = require("express");
const PettyCashVoucherRouter = express.Router();

const {CreateVoucher, GetAllVouchers, DeleteVouchers} = require("../controllers/pcv.controller");

PettyCashVoucherRouter.post("/", CreateVoucher);
PettyCashVoucherRouter.get("/", GetAllVouchers);
PettyCashVoucherRouter.delete("/:id", DeleteVouchers);

module.exports = PettyCashVoucherRouter;