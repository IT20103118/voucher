import { height } from "@mui/system";
import React, { Component } from "react";
import Navbar2 from "./Navbar2";

const Userlist = () => {
  window.location = `/user/all`;
};

export default class Dashboard extends Component {
  render() {
    return (
      <div>
        <Navbar2 />
        {/* <div class="col" style={{ width: "40rem", color: "white" }}>
          <div class="shadow h-60" id="cardcol1"> } */}
        <div 
          class="card-body"
          style={{ color: "white", background: "#151B54", height: "40px", width: "40rem"}}
          onClick={Userlist}
        >
          <h5 class="card-title" id="dashh5" align="center">
            <b> User List</b>
          </h5>
        </div>
        {/* </div>
        </div>

        {/* <div class="col" style={{ width: "20rem", color: "white" }}>
          <div class="shadow h-60" id="cardcol1">
            <div
              class="card-body"
              style={{ background: "#151B54" }}
              onClick={Userlist}
            >
              <h5 class="card-title" id="dashh5" align="center">
                <b> User List</b>
              </h5>
            </div>
          </div>
        </div> */}
      </div>
    );
  }
}
